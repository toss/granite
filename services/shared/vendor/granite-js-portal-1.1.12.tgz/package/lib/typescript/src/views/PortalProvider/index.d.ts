import type { PortalProviderProps } from "../../types";
export default function PortalProvider({ children }: PortalProviderProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=index.d.ts.map