export default function useId(prefix?: string): string;
//# sourceMappingURL=useId.d.ts.map