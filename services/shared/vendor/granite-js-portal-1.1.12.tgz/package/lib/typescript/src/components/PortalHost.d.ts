import type { PortalHostProps } from "../types";
/**
 * PortalHost is a component that acts as an anchor for the portals.
 * You can define multiple portal hosts in your app and use them to render different portals.
 * Each portal host has a unique name that you can use to identify a necessary one among the others.
 *
 * @category components
 * @param name - The name of the portal host. It's used by `<Portal />` component to identify the host.
 *
 * @example
 * ```tsx
 * import { StyleSheet, View } from "react-native";
 * import { PortalHost, PortalProvider } from "@granite-js/portal";
 * export default function App() {
 *   return (
 *     <PortalProvider>
 *        <PortalHost style={StyleSheet.absoluteFillObject} name="overlay" />
 *     </PortalProvider>
 *   );
 * }
 * ```
 */
declare const PortalHostComponent: ({ name, children, style }: PortalHostProps) => import("react/jsx-runtime").JSX.Element;
export default PortalHostComponent;
//# sourceMappingURL=PortalHost.d.ts.map