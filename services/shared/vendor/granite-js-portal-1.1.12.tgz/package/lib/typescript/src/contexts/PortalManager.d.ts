import { type ReactNode } from "react";
import { type Action, type PortalState } from "../state/reducer";
export declare const PortalManagerProvider: ({ children, }: {
    children: ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
export declare const usePortalManagerContext: () => {
    state: PortalState;
    dispatch: React.Dispatch<Action>;
};
//# sourceMappingURL=PortalManager.d.ts.map