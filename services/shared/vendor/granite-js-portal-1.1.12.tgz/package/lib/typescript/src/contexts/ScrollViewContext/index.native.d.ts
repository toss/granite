import type { Context } from "react";
import type { ScrollViewContextValue } from "./types";
declare const ScrollViewContext: Context<ScrollViewContextValue>;
export default ScrollViewContext;
//# sourceMappingURL=index.native.d.ts.map