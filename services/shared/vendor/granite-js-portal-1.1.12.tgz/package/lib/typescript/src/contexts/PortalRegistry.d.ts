type PortalRegistryContextType = {
    registerHost: (name: string, node: HTMLElement | null) => void;
    getHost: (name: string) => HTMLElement | null;
    registerPendingPortal: (name: string, callback: () => void) => void;
    unregisterPendingPortal: (name: string, callback: () => void) => void;
};
export declare const PortalRegistryContext: import("react").Context<PortalRegistryContextType | null>;
export declare function usePortalRegistryContext(): PortalRegistryContextType;
export {};
//# sourceMappingURL=PortalRegistry.d.ts.map