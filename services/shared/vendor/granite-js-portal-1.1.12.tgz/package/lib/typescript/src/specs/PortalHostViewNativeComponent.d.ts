import { type ViewProps } from "react-native";
interface NativeProps extends ViewProps {
    name?: string;
}
declare const _default: import("react-native/types_generated/Libraries/Utilities/codegenNativeComponent").NativeComponentType<NativeProps>;
export default _default;
//# sourceMappingURL=PortalHostViewNativeComponent.d.ts.map