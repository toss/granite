import type { ScrollViewContextValue } from "./types";
declare const ScrollViewContext: import("react").Context<ScrollViewContextValue>;
export default ScrollViewContext;
//# sourceMappingURL=index.d.ts.map