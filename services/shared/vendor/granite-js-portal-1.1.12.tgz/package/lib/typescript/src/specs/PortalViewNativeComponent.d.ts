import { type ViewProps } from "react-native";
interface NativeProps extends ViewProps {
    name?: string;
    hostName?: string;
}
declare const _default: import("react-native/types_generated/Libraries/Utilities/codegenNativeComponent").NativeComponentType<NativeProps>;
export default _default;
//# sourceMappingURL=PortalViewNativeComponent.d.ts.map