import type { PortalProviderProps } from "../../types";
export default function PortalProvider({ children }: PortalProviderProps): import("react").ReactNode;
//# sourceMappingURL=index.native.d.ts.map