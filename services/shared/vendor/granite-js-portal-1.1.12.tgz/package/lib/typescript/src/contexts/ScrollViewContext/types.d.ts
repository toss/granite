export type ScrollViewContextValue = {
    horizontal: boolean;
} | null;
//# sourceMappingURL=types.d.ts.map