export { default } from "../../specs/PortalViewNativeComponent";
//# sourceMappingURL=index.native.d.ts.map