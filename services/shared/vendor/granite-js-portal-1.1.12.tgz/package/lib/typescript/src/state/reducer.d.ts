import type { ScrollViewContextValue } from "../contexts/ScrollViewContext/types";
export type PortalState = {
    removed: Record<string, Record<string, Record<string, boolean>>>;
    hosts: Record<string, number>;
    hostScrollViewContexts: Record<string, ScrollViewContextValue | undefined>;
};
export type Action = {
    type: "REMOVE_PORTAL";
    hostName: string;
    name: string;
} | {
    type: "CLEAR_REMOVED_ON_UNMOUNT";
    hostName: string;
    name: string;
    instanceId: string;
} | {
    type: "REGISTER_PORTAL";
    hostName: string;
    name: string;
    instanceId: string;
} | {
    type: "REGISTER_HOST";
    hostName: string;
} | {
    type: "UNREGISTER_HOST";
    hostName: string;
} | {
    type: "SET_HOST_SCROLL_VIEW_CONTEXT";
    hostName: string;
    value: ScrollViewContextValue;
};
export declare const initialState: PortalState;
export declare const reducer: (state: PortalState, action: Action) => PortalState;
//# sourceMappingURL=reducer.d.ts.map