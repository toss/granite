import type { PortalHostProps } from "../../types";
declare const PortalHost: (props: PortalHostProps) => import("react/jsx-runtime").JSX.Element;
export default PortalHost;
//# sourceMappingURL=index.native.d.ts.map