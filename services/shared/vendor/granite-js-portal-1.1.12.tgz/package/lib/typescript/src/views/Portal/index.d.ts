import type { PortalProps } from "../../types";
export default function Portal({ hostName, children, style }: PortalProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=index.d.ts.map