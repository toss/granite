import type { PortalHostProps } from "../../types";
declare function PortalHost({ name, children, style }: PortalHostProps): import("react/jsx-runtime").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof PortalHost>;
export default _default;
//# sourceMappingURL=index.d.ts.map